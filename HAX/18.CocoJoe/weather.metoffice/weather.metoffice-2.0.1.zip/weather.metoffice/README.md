weather.metoffice ![Codeship Status](https://codeship.com/projects/e7173200-c9e2-0133-bce4-0aabfff4550a/status?branch=krypton)
======================

Weather plugin for Kodi. Fetches data from the UK Met Office.
