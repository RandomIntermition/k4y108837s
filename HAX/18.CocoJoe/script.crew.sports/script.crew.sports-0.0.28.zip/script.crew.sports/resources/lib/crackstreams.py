
import base64, codecs
thecrew = 'aW1wb3J0IHJlcXVlc3RzCmZyb20gYnM0IGltcG9ydCBCZWF1dGlmdWxTb3VwCmltcG9ydCByZQpnYW1lX2xpc3QgPSBbXQoKZGVmIGdldF9nYW1lKCk6CiAgICBjb25uID0gcmVxdWVzdHMuZ2V0KHIiaHR0cDovLzE5Mi4yNDMuMTAwLjIwNy9zdHJlYW1zL2NyYWNrc3RyZWFtcy9jcmFja3N0cmVhbXMueG1sIikKICAgIHRpd'
doesnt = 'TkyVQ0tpzHhL29gpTyfMFtvCUEcqTkyCvthXm8cCP90nKEfMG4vXF5znJ5xLJkfXTAioz4hqTI4qPxXVPNtVTkcozftCFOlMF5wo21jnJkyXPV8oTyhnm4bYvf/XGjioTyhnm4vXF5znJ5xLJkfXTAioz4hqTI4qPxXVPNtVTxtCFNjPvNtVPOcMvO0nKEfMFOipvOfnJ5eBtbtVPNtVPNtVUqbnJkyVTxtCPOfMJ4bqTy0oTHcBt'
do = 'ogICAgICAgICAgICBpZiAnbmZsJyBpbiB0aXRsZVtpXS5lbmNvZGUoJ2FzY2lpJywnaWdub3JlJykubG93ZXIoKToKICAgICAgICAgICAgICAgIGkgKz0gMQogICAgICAgICAgICAgICAgY29udGludWUKICAgICAgICAgICAgICAgIAogICAgICAgICAgICBnYW1lX2xpc3QuYXBwZW5kKHsndGl0bGUnOnRpdGxlW2ldLmVuY29'
drama = 'xMFtaLKAwnJxaYPqcM25ipzHaXFjap3ElMJSgWmcfnJ5eJ2yqYzIhL29xMFtaLKAwnJxaYPqcM25ipzHaXF5lMKOfLJAyXPqFMJMypzIlWljapzIzMKWypvpcsFxXVPNtVPNtVPNtVPNtnFNeCFNkPvNtVPOyoUAyBtbtVPNtVPNtVUOup3ZXPvNtVPOlMKE1pz4tM2SgMI9fnKA0PtbXpUWcoaDbM2I0K2quoJHbXFxXVPNtVNb='
respect = '\x72\x6f\x74\x31\x33'
usandyou = eval('\x74\x68\x65\x63\x72\x65\x77') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x64\x6f\x65\x73\x6e\x74\x2c\x20\x72\x65\x73\x70\x65\x63\x74\x29') + eval('\x64\x6f') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x64\x72\x61\x6d\x61\x2c\x20\x72\x65\x73\x70\x65\x63\x74\x29')
eval(compile(base64.b64decode(eval('\x75\x73\x61\x6e\x64\x79\x6f\x75')),'<string>','exec'))