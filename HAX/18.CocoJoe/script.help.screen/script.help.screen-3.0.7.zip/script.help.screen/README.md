Help Screen
===============
basic addon to display keymap details to user

settings can be used to load different keyboard configs
